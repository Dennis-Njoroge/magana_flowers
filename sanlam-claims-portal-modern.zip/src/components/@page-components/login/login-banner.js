import Box from "@mui/material/Box";
import LoginLottie from "@/components/@shared-components/lottie-files/login-lottie";
import {Typography} from "@mui/material";

const LoginBanner = () => {
    return (
        <>
            <Box sx={{
                borderRadius: 3,
                width: "100%",
                display: 'flex',
                flexDirection: 'column',
            }}>
                <Typography variant={'h5'} align={'center'}  gutterBottom>
                    {"Sanlam Claims Portal"}
                </Typography>
                <LoginLottie/>
                <Typography variant={'caption'} align={'center'}>
                    Copyright { '\u00a9'} {new Date().getFullYear()} | All Rights Reserved |
                    Sanlam Limited is the licensed controlling company of the Sanlam Limited Insurance Group. Sanlam Life Insurance Limited is an insurer licensed to conduct life insurance business and is a licensed financial services provider and a registered credit provider.
                </Typography>
            </Box>
        </>
    )
}

export default LoginBanner;