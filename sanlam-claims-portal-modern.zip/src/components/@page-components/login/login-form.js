import {useFormik} from "formik";
import {Alert, Button, Grid, Typography} from "@mui/material";
import * as Yup from "yup";
import Box from "@mui/material/Box";
import {sanitizeString} from "@/utils/helper-functions";
import Collapse from "@mui/material/Collapse";
import {Logo} from "@/components/logo";
import DMTPhoneInput from "@/components/@shared-components/forms/phone-input";

const LoginForm = props => {
    const { onLogin } = props;
    const formik = useFormik({
        initialValues: {
            phoneNumber: "",
            countryCode: "+254",
            password: "",
            rememberMe: false,
            submit: null,
        },
        validationSchema: Yup.object().shape({
            phoneNumber: Yup.string()
                .min(9, "Invalid Number Provided")
                .max(10, "Invalid Number Provided")
                .required("Phone number is required!")
            ,
        }),
        onSubmit: async (values, helpers) => {
            try{
                await onLogin(values, (error) => formik.setFieldError('submit', error))
            }
            catch (e) {
                helpers.setSubmitting(false);
               console.log(e.message);
            }
        }
    });

    const handleOnChange = e => {
        const { name, value } = e.target;
        formik.setFieldValue(name, sanitizeString(value));
    };


    return (
        <>
            <Box
                sx={{
                    backgroundColor: 'background.paper',
                    borderRadius: 2,
                    boxShadow: 5,
                    px:{md: 4, sm:2, xs: 2},
                    pt:{md: 4, sm:2, xs: 2},
                    pb:{md: 8, sm:2, xs: 2}
                }}
                component={'form'}
                onSubmit={formik.handleSubmit}
            >
                <Grid container spacing={2} >
                    <Grid item xs={12} sm={12} md={12} lg={12}>
                        <Logo/>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} lg={12}>

                        <Typography variant={'body2'} align={"center"} gutterBottom>
                            {"Sign in to your account"}
                        </Typography>
                        <Collapse in={Boolean(formik.errors.submit)}>
                            {Boolean(formik.errors.submit) && (
                                <Alert severity={"error"} variant={"standard"}>
                                    {formik.errors.submit}
                                </Alert>
                            ) }
                        </Collapse>
                    </Grid>
                    <Grid item xs={12} sm={12} md={12} lg={12}>
                        <DMTPhoneInput
                            label={"Phone Number"}
                            fullWidth={true}
                            autoFocus={true}
                            countryCode={formik.values.countryCode}
                            value={formik.values.phoneNumber}
                            onChangeCountryCode={formik.handleChange}
                            name = "phoneNumber"
                            type={"phoneNumber"}
                            error={Boolean(formik.touched.phoneNumber && formik.errors.phoneNumber)}
                            helperText={formik.touched.phoneNumber && formik.errors.phoneNumber}
                            onChange={handleOnChange}
                        />
                    </Grid>

                    <Grid item xs={12} sm={12} md={12} lg={12}>
                        <Button
                            type={"submit"}
                            variant={"contained"}
                            color={"primary"}
                            size={'large'}
                            sx={{ mt: 2}}
                            fullWidth={true}
                            disabled={formik.isSubmitting}
                        >
                            {formik.isSubmitting ? "Validating..." : "Login"}
                        </Button>
                    </Grid>
                </Grid>

            </Box>

        </>
    )
}

export default LoginForm;